from fastapi import APIRouter
from core.http import get_client

router = APIRouter()

@router.get("/healthz")
async def healthz():
    # simple: client exists / can be constructed
    await get_client()
    return {"ok": True}

@router.get("/readyz")
async def readyz():
    return {"ready": True}
