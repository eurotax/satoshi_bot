from core.http import get_json
from typing import List, Dict

# Public docs: https://www.geckoterminal.com/api/docs
API = "https://api.geckoterminal.com/api/v2/search/pools"

async def fetch_pools(query: str = "SOL") -> List[Dict]:
    data = await get_json(API, params={"query": query, "include": "base_token,quote_token"})
    out: List[Dict] = []
    for d in data.get("data", []):
        attrs = d.get("attributes", {})
        chain = (attrs.get("network") or "").upper()
        symbol = attrs.get("name") or "?/?"
        price = attrs.get("price_in_usd") or 0
        liq = attrs.get("reserve_in_usd") or 0
        vol1 = attrs.get("volume_usd", {}).get("h1", 0) if isinstance(attrs.get("volume_usd"), dict) else 0
        out.append({
            "src": "geckoterminal",
            "chain": chain,
            "pair_id": d.get("id"),
            "symbol": symbol,
            "price": float(price) if price else 0,
            "liquidity": int(liq or 0),
            "vol_5m": 0.0,
            "vol_1h": float(vol1 or 0),
            "tx_buy_5m": 0,
            "tx_sell_5m": 0,
            "age_min": 0,
            "vl_ratio": (float(vol1 or 0) / float(liq or 1)) if liq else 0.0,
            "price_change_5m": 0.0,
            "link_chart": attrs.get("pool_url"),
            "contract": None,
        })
    return out
