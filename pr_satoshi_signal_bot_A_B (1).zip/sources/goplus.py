from core.http import get_json
from typing import Optional
import os

API = "https://api.gopluslabs.io/api/v1/token_security/2"

async def token_risk(address: str) -> Optional[dict]:
    key = os.getenv("GOPLUS_API_KEY")
    params = {"contract_addresses": address}
    headers = {"API-KEY": key} if key else None
    try:
        data = await get_json(API, params=params, headers=headers)
        return data
    except Exception:
        return None
