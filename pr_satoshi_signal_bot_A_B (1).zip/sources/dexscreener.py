from core.http import get_json
from typing import List, Dict

DEXSCREENER_SEARCH = "https://api.dexscreener.com/latest/dex/search"

async def fetch_pairs(query: str = "SOL") -> List[Dict]:
    data = await get_json(DEXSCREENER_SEARCH, params={"q": query})
    out: List[Dict] = []
    for p in data.get("pairs", []):
        chain = (p.get("chainId") or "").upper()
        symbol = f"{p.get('baseToken',{}).get('symbol','?')}/{p.get('quoteToken',{}).get('symbol','?')}"
        liq = (p.get("liquidity") or {}).get("usd", 0) or 0
        vol5 = (p.get("txns") or {}).get("m5", {}).get("volume", 0) or 0
        vol1 = (p.get("volume", {}) or {}).get("h1", 0) or 0
        tx5b = (p.get("txns") or {}).get("m5", {}).get("buys", 0) or 0
        tx5s = (p.get("txns") or {}).get("m5", {}).get("sells", 0) or 0
        age_min = 0
        if p.get("pairCreatedAt"):
            import time
            age_min = int((time.time()*1000 - int(p["pairCreatedAt"])) / 60000)
        price = p.get("priceUsd") or 0
        out.append({
            "src": "dexscreener",
            "chain": chain,
            "pair_id": p.get("pairAddress"),
            "symbol": symbol,
            "price": float(price) if price else 0,
            "liquidity": int(liq),
            "vol_5m": float(vol5),
            "vol_1h": float(vol1),
            "tx_buy_5m": int(tx5b),
            "tx_sell_5m": int(tx5s),
            "age_min": int(age_min),
            "vl_ratio": (float(vol1) / liq) if liq else 0.0,
            "price_change_5m": float((p.get("priceChange", {}) or {}).get("m5", 0) or 0),
            "link_chart": p.get("url"),
            "contract": (p.get("baseToken") or {}).get("address"),
        })
    return out
