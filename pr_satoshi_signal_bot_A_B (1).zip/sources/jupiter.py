from core.http import get_json
from typing import Dict, Optional

API = "https://quote-api.jup.ag/v6/quote"

async def best_quote(input_mint: str, output_mint: str, amount: int) -> Optional[Dict]:
    params = {"inputMint": input_mint, "outputMint": output_mint, "amount": amount}
    try:
        data = await get_json(API, params=params)
        return data
    except Exception:
        return None
