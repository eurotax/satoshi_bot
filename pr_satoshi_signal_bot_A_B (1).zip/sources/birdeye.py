from core.http import get_json
from typing import List, Dict
import os

API = "https://public-api.birdeye.so/defi/price"

async def fetch_tokens(symbols: list[str]) -> List[Dict]:
    key = os.getenv("BIRDEYE_API_KEY")
    headers = {"X-API-KEY": key} if key else None
    out: List[Dict] = []
    for s in symbols:
        data = await get_json(API, params={"address": s}, headers=headers)
        # NOTE: Birdeye returns token-centric data; mapping to unified shape is simplified
        out.append({
            "src": "birdeye",
            "chain": "SOL",
            "pair_id": s,
            "symbol": s,
            "price": float(data.get("data", {}).get("value", 0) or 0),
            "liquidity": 0,
            "vol_5m": 0.0,
            "vol_1h": 0.0,
            "tx_buy_5m": 0,
            "tx_sell_5m": 0,
            "age_min": 0,
            "vl_ratio": 0.0,
            "price_change_5m": 0.0,
            "link_chart": None,
            "contract": s,
        })
    return out
