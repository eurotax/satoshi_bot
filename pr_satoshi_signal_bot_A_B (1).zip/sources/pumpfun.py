from typing import List, Dict

async def stream_new_tokens() -> List[Dict]:
    # Placeholder: in production use WS (subscribeNewToken). Here we return empty (integration hook).
    return []
