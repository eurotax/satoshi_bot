# For ultra-early listings you would connect to Raydium WS/new pools endpoints.
# This stub exists as an integration hook.
async def stream_new_pools():
    return []
