Każdy adapter zwraca listę słowników "sig" w ustandaryzowanym kształcie:
{
  "src": "dexscreener|geckoterminal|birdeye|pumpfun|raydium|jupiter|goplus",
  "chain": "SOL|ETH|BSC|...",
  "pair_id": "...",
  "symbol": "COIN/USDC",
  "price": 0.0,
  "liquidity": 0,
  "vol_5m": 0,
  "vol_1h": 0,
  "tx_buy_5m": 0,
  "tx_sell_5m": 0,
  "age_min": 0,
  "vl_ratio": 0.0,
  "price_change_5m": 0.0,
  "link_chart": "https://...",
  "contract": "0x..."
}
