# PR: Stabilność + Filtry/Scoring + Formatowanie + Nowe Źródła (A+B)

Data: 2025-08-09

## Co zawiera PR
**A. Stabilność i jakość sygnałów**
- `settings.py` (ENV przez pydantic-settings, `.env.example`)
- `core/http.py` (AsyncClient + retry/backoff + UA)
- `core/state.py` (dedup przez aiosqlite)
- `core/format.py` (MarkdownV2-safe + formaty public/VIP)
- `filters/quality.py` (scoring 0–100 + „reasons”)
- `scheduler/locks.py` (mutex)
- `routes/health.py` (`/healthz`, `/readyz`)
- `requirements.append.txt` (nowe zależności)

**B. Nowe źródła (adaptery)**
- `sources/dexscreener.py` (REST)
- `sources/geckoterminal.py` (REST)
- `sources/birdeye.py` (REST; ws pod Solanę można dodać później)
- `sources/pumpfun.py` (hook pod WS)
- `sources/jupiter.py` (walidacja ceny/slippage)
- `sources/goplus.py` (risk gate)
- `sources/raydium.py` (hook)

## Integracja z istniejącym botem (kroki)
1. Skopiuj foldery `core/`, `filters/`, `sources/`, `routes/`, `scheduler/locks.py`, `settings.py`, `.env.example` do repo.
2. Uzupełnij `requirements.txt` o zawartość z `requirements.append.txt`.
3. W kodzie skanera/publish:
   - Zastąp dotychczasowe wywołania HTTP funkcjami z `core/http.py`.
   - Przed publikacją sprawdzaj dedup: `seen_before(f"{{sig['src']}}:{{sig['pair_id']}}", tier)`.
   - Wylicz score: `score, reasons = score_signal(sig)`; dołącz `sig["score"]=score; sig["reasons"]=reasons`.
   - Wybór progu: `MIN_SCORE_VIP` dla VIP i `MIN_SCORE_PUBLIC` dla public.
   - Formatowanie: `build_public_message(sig)` / `build_vip_message(sig)`.
4. Dodaj HTTP endpointy `/healthz` i `/readyz` do aplikacji FastAPI (jeśli używasz).
5. Ustaw `.env` na bazie `.env.example` (nie commituj `.env`).

## Uruchomienie lokalne
```bash
pip install -r requirements.txt
cp .env.example .env  # uzupełnij tokeny i progi
python -c "from core.state import init; import asyncio; asyncio.run(init())"
# uruchom bota tak jak dotąd
```

## Notatki
- Redis może zastąpić aiosqlite w `core/state.py` – struktura klucza: `seen:{tier}:{src}:{pair_id}`, TTL=24h.
- WS (Birdeye/Pump.fun/Raydium) zalecane w kolejnej iteracji (runtime loop + reconnect).
