import httpx
import asyncio
from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
from typing import Any, Dict, Optional
from settings import settings

class RetryableError(Exception):
    pass

_client: httpx.AsyncClient | None = None
_client_lock = asyncio.Lock()

async def get_client() -> httpx.AsyncClient:
    global _client
    async with _client_lock:
        if _client is None:
            _client = httpx.AsyncClient(
                timeout=httpx.Timeout(settings.HTTP_TIMEOUT_SECONDS),
                headers={"User-Agent": "SatoshiSignalBot/1.0 (+bot)"},
                limits=httpx.Limits(max_connections=settings.HTTP_POOL_LIMIT),
            )
        return _client

@retry(
    reraise=True,
    stop=stop_after_attempt(4),
    wait=wait_exponential_jitter(initial=0.5, max=6.0),
    retry=retry_if_exception_type(RetryableError),
)
async def get_json(url: str, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> Any:
    client = await get_client()
    r = await client.get(url, params=params, headers=headers)
    if r.status_code in (429, 502, 503, 504):
        raise RetryableError(f"Upstream {r.status_code}")
    r.raise_for_status()
    return r.json()

async def aclose():
    global _client
    if _client:
        await _client.aclose()
        _client = None
