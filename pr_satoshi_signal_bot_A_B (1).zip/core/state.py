import aiosqlite, time, os, asyncio
DB_PATH = os.getenv("STATE_DB_PATH", "/tmp/satoshi_state.db")
_init_lock = asyncio.Lock()

async def init():
    async with _init_lock:
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("CREATE TABLE IF NOT EXISTS seen (id TEXT PRIMARY KEY, ts INTEGER, tier TEXT)")
            await db.commit()

async def seen_before(key: str, tier: str, ttl_hours: int = 24) -> bool:
    cutoff = int(time.time()) - ttl_hours*3600
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT ts FROM seen WHERE id=? AND tier=?", (key, tier))
        row = await cur.fetchone()
        if row and row[0] >= cutoff:
            return True
        await db.execute("INSERT OR REPLACE INTO seen(id, ts, tier) VALUES(?, ?, ?)", (key, int(time.time()), tier))
        await db.commit()
    return False
