from typing import Dict

MDV2_CHARS = r"_*[]()~`>#+-=|{}.!\""

def mdv2_escape(text: str) -> str:
    out = []
    for c in text:
        if c in MDV2_CHARS:
            out.append("\\" + c)
        else:
            out.append(c)
    return "".join(out)

def build_public_message(sig: Dict) -> str:
    # Required keys in sig: chain, symbol, price, liquidity, vol_5m, link_chart
    parts = []
    title = f"⚡️ [{sig.get('chain','?')}] {sig.get('symbol','?')}"
    parts.append(mdv2_escape(title))
    parts.append(f"• Cena: {sig.get('price','?')} | Liq: ${sig.get('liquidity','?')} | Vol5m: ${sig.get('vol_5m','?')}")
    parts.append("🔗 Wykres")
    return "\n".join(parts)

def build_vip_message(sig: Dict) -> str:
    # Includes extended metrics and score
    title = f"⚡️ [{sig.get('chain','?')}] {sig.get('symbol','?')} — score {sig.get('score','?')}/100"
    parts = [mdv2_escape(title)]
    parts.append(f"• Cena: {sig.get('price','?')} | Liq: ${sig.get('liquidity','?')} | Vol5m: ${sig.get('vol_5m','?')} | Vol1h: ${sig.get('vol_1h','?')}")
    parts.append(f"• Tx5m: {sig.get('tx_buy_5m','?')}/{sig.get('tx_sell_5m','?')} | Wiek: {sig.get('age_min','?')} min | V/L: {sig.get('vl_ratio','?')}")
    reasons = ", ".join(sig.get("reasons", [])) or "—"
    parts.append(f"• Powody: {mdv2_escape(reasons)}")
    parts.append("🔗 Wykres | Kontrakt | Pool | Zgłoś scam")
    return "\n".join(parts)
