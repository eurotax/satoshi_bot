from pydantic_settings import BaseSettings
from pydantic import Field
from typing import List

class Settings(BaseSettings):
    # Telegram
    BOT_TOKEN: str
    PUBLIC_CHANNEL_ID: str
    VIP_CHANNEL_ID: str

    # General
    ENV: str = "dev"

    # Filters / scoring
    MIN_LIQUIDITY: int = 100_000
    MIN_VOL_5M: int = 5_000
    MIN_VOL_1H: int = 25_000
    MIN_TX_BUY_5M: int = 20
    MIN_TX_SELL_5M: int = 15
    MIN_PAIR_AGE_MIN: int = 60
    MIN_SCORE_PUBLIC: int = 60
    MIN_SCORE_VIP: int = 70
    ALLOWED_CHAINS: List[str] = Field(default_factory=lambda: ["SOL", "ETH", "BSC"])

    # HTTP / rate limits
    HTTP_TIMEOUT_SECONDS: float = 8.0
    HTTP_POOL_LIMIT: int = 50
    REQS_PER_MIN_DEXSCREENER: int = 120
    REQS_PER_MIN_GECKOTERMINAL: int = 120
    REQS_PER_MIN_BIRDEYE: int = 180
    REQS_PER_MIN_JUPITER: int = 180
    REQS_PER_MIN_GOPLUS: int = 60

    # Observability
    SENTRY_DSN: str | None = None
    PROMETHEUS_PORT: int = 8001

    # API keys (optional)
    BIRDEYE_API_KEY: str | None = None
    GOPLUS_API_KEY: str | None = None

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
