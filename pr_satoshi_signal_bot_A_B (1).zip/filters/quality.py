from settings import settings
from typing import Dict, List

def score_signal(sig: Dict) -> tuple[int, List[str]]:
    score = 0
    reasons: List[str] = []
    # Chain allowlist
    chain = (sig.get("chain") or "").upper()
    if chain not in settings.ALLOWED_CHAINS:
        return 0, ["chain not allowed"]

    liq = float(sig.get("liquidity", 0) or 0)
    if liq >= settings.MIN_LIQUIDITY:
        score += 20; reasons.append("liq>=min")

    vol5 = float(sig.get("vol_5m", 0) or 0)
    vol1h = float(sig.get("vol_1h", 0) or 0)
    if vol5 >= settings.MIN_VOL_5M:
        score += 10; reasons.append("vol5m>=min")
    if vol1h >= settings.MIN_VOL_1H:
        score += 10; reasons.append("vol1h>=min")

    txb = int(sig.get("tx_buy_5m", 0) or 0)
    txs = int(sig.get("tx_sell_5m", 0) or 0)
    if txb >= settings.MIN_TX_BUY_5M and txs >= settings.MIN_TX_SELL_5M:
        score += 10; reasons.append("tx5m>=min")

    age = int(sig.get("age_min", 0) or 0)
    if age >= settings.MIN_PAIR_AGE_MIN:
        score += 20; reasons.append("age>=min")

    vl_ratio = float(sig.get("vl_ratio", 0) or 0)
    # Healthy ratio ~ 0.02 - 0.5 (heuristic); points if in range
    if 0.02 <= vl_ratio <= 0.5:
        score += 10; reasons.append("V/L ok")

    # Price momentum (optional field)
    pc_5m = float(sig.get("price_change_5m", 0) or 0)
    if pc_5m >= 2.0:
        score += 10; reasons.append("momentum")

    return score, reasons
