from datetime import timedelta
from telegram.ext import Application, ContextTypes
from settings import settings
from core.state import init as state_init, seen_before
from core.http import aclose as http_close
from scheduler.locks import publish_lock
from filters.quality import score_signal
from core.format import build_public_message, build_vip_message

from sources.dexscreener import fetch_pairs as ds_fetch
from sources.geckoterminal import fetch_pools as gt_fetch
# Birdeye/Jupiter/GoPlus są gotowe do użycia przy rozbudowie o wsparcie mint/kontraktów

PUBLIC_INTERVAL = timedelta(hours=8)
VIP_INTERVAL     = timedelta(minutes=15)

def _normalize(sig: dict) -> dict:
    """Ujednolica klucze i wypełnia brakujące wartości domyślne."""
    return {
        "src": sig.get("src"),
        "chain": (sig.get("chain") or "").upper(),
        "pair_id": sig.get("pair_id") or sig.get("contract") or sig.get("symbol"),
        "symbol": sig.get("symbol") or "?/?",
        "price": sig.get("price", 0) or 0,
        "liquidity": int(sig.get("liquidity", 0) or 0),
        "vol_5m": float(sig.get("vol_5m", 0) or 0),
        "vol_1h": float(sig.get("vol_1h", 0) or 0),
        "tx_buy_5m": int(sig.get("tx_buy_5m", 0) or 0),
        "tx_sell_5m": int(sig.get("tx_sell_5m", 0) or 0),
        "age_min": int(sig.get("age_min", 0) or 0),
        "vl_ratio": float(sig.get("vl_ratio", 0) or 0),
        "price_change_5m": float(sig.get("price_change_5m", 0) or 0),
        "link_chart": sig.get("link_chart"),
        "contract": sig.get("contract"),
    }

async def _gather_signals() -> list[dict]:
    # 1) Dexscreener
    ds = await ds_fetch("SOL")
    # 2) GeckoTerminal
    gt = await gt_fetch("SOL")

    # merge (prosty: konkatenacja, dedup po pair_id+src później)
    merged = [*_map_all(ds), *_map_all(gt)]
    # dedup w obrębie niniejszej listy (para src+pair_id)
    seen = set()
    uniq = []
    for s in merged:
        key = f"{s.get('src')}:{s.get('pair_id')}"
        if key in seen:
            continue
        seen.add(key)
        uniq.append(s)
    return uniq

def _map_all(lst: list[dict]) -> list[dict]:
    return [_normalize(x) for x in lst]

async def _process_and_send(context, tier: str):
    for sig in await _gather_signals():
        score, reasons = score_signal(sig)
        min_score = settings.MIN_SCORE_VIP if tier == "vip" else settings.MIN_SCORE_PUBLIC
        if score < min_score:
            continue
        sig["score"], sig["reasons"] = score, reasons
        if await seen_before(f"{sig['src']}:{sig['pair_id']}", tier):
            continue
        text = build_vip_message(sig) if tier == "vip" else build_public_message(sig)
        chat_id = settings.VIP_CHANNEL_ID if tier == "vip" else settings.PUBLIC_CHANNEL_ID
        await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="MarkdownV2", disable_web_page_preview=False)

async def scan_publish_public(context: ContextTypes.DEFAULT_TYPE) -> None:
    async with publish_lock:
        await _process_and_send(context, "public")

async def scan_publish_vip(context: ContextTypes.DEFAULT_TYPE) -> None:
    async with publish_lock:
        await _process_and_send(context, "vip")

async def on_startup(app: Application) -> None:
    await state_init()
    jq = app.job_queue
    jq.run_repeating(scan_publish_public, interval=PUBLIC_INTERVAL, first=10, name="public")
    jq.run_repeating(scan_publish_vip,    interval=VIP_INTERVAL,    first=20, name="vip")

async def on_shutdown(app: Application) -> None:
    await http_close()
